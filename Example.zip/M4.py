import cv2
import matplotlib.pyplot as plt
from skimage.filters import roberts, sobel, prewitt

img = cv2.imread('Home.jpg',0)
# Canny
edge_canny = cv2.Canny(img,100,200)
# Calcution of Sobel
edge_sobel = sobel(img)
# Prewitt Operator
edge_prewitt = prewitt(img)
#Robert
edge_roberts = roberts(img)

plt.subplot(2,3,1)
plt.imshow(img,cmap='gray')
plt.title('Orignal')
plt.subplot(2,3,2)
plt.imshow(edge_canny,cmap='gray')
plt.title('Canny')
plt.subplot(2,3,3)
plt.imshow(edge_sobel,cmap='gray')
plt.title('Sobel')
plt.subplot(2,3,4)
plt.imshow(edge_prewitt,cmap='gray')
plt.title('Prewitt')
plt.subplot(2,3,5)
plt.imshow(edge_roberts,cmap='gray')
plt.title('Roberts')
plt.show()

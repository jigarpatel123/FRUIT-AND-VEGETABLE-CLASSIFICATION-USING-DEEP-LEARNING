# https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_imgproc/py_morphological_ops/py_morphological_ops.html?highlight=morphological
import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('j.png')
kernel = np.ones((5,5),np.uint8)
# Erosion
erosion = cv2.erode(img,kernel,iterations = 1)
# dilation
dilation = cv2.dilate(img,kernel,iterations = 1)
# opening
opening = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)
# closing
closing = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel)


fig=plt.figure()
ax1=fig.add_subplot(2,3,1)
plt.imshow(img)
ax1.title.set_text('Orignal')
ax2=fig.add_subplot(2,3,2)
plt.imshow(erosion)
ax2.title.set_text('Erosion')
ax3=fig.add_subplot(2,3,3)
plt.imshow(dilation)
ax3.title.set_text('Dilation')
ax4=fig.add_subplot(2,3,4)
plt.imshow(opening)
ax4.title.set_text('Opening')
ax5=fig.add_subplot(2,3,5)
plt.imshow(closing)
ax5.title.set_text('Closing')
plt.show()
